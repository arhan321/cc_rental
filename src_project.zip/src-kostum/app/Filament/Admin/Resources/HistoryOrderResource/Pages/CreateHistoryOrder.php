<?php

namespace App\Filament\Admin\Resources\HistoryOrderResource\Pages;

use App\Filament\Admin\Resources\HistoryOrderResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateHistoryOrder extends CreateRecord
{
    protected static string $resource = HistoryOrderResource::class;
}
